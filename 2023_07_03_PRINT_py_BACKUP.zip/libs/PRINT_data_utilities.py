#   This work is licensed under Creativ Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
#   (https://creativecommons.org/licenses/by-sa/4.0/). Feel free to use, modify or distribute this code as  
#   far as you like, so long as you make anything based on it publicly avialable under the same license.


#######################################     IMPORTS      #####################################################

import re 
import os
import copy
import socket
import struct
import math as m

from pathlib import Path
from datetime import datetime
# import time



#############################################################################################
#                                    CLASSES
#############################################################################################

class Coor:
    """standard 7-axis coordinate block (8 attributes, as quaterion positioning is possible)

    ATTRIBUTES:
        X, Y, Z:
            position in cartesian coordinates
        X_ori, Y_ori, Z_ori:
            angle relative to cartesian coordinates
        Q:
            additional var for fourth quaternion coordinate
        EXT:
            external axis position

    FUNCTIONS:
        __init__
        __str__
        __add__
    """

    def __init__(self,
                 X  	= 0.0, 
                 Y  	= 0.0, 
                 Z  	= 0.0, 
                 X_ori  = 0.0, 
                 Y_ori  = 0.0, 
                 Z_ori  = 0.0, 
                 Q      = 0.0, 
                 EXT    = 0.0):
        
        self.X      = X
        self.Y      = Y
        self.Z      = Z
        self.X_ori  = X_ori
        self.Y_ori  = Y_ori
        self.Z_ori  = Z_ori
        self.Q      = Q
        self.EXT    = EXT
    


    def __str__(self):

        return f"X: {self.X}   Y: {self.Y}   Z: {self.Z}   Rx: {self.X_ori}   Ry: {self.Y_ori}   Rz: {self.Z_ori}   " \
               f"Q: {self.Q}   EXT: {self.EXT}"
    


    def __add__(self,summand):

        return Coor( (self.X        + summand.X)
                    ,(self.Y        + summand.Y)
                    ,(self.Z        + summand.Z)
                    ,(self.X_ori    + summand.X_ori)
                    ,(self.Y_ori    + summand.Y_ori)
                    ,(self.Z_ori    + summand.Z_ori)
                    ,(self.Q        + summand.Q)
                    ,(self.EXT      + summand.EXT) )




class Speed:
    """standard speed vector (4 attributes).

    ATTRIBUTES:
        TS:
            transition speed
        OR:
            orientation speed
        ACR:
            acceleration ramp
        DCR:
            deceleration ramp
    
    FUNCTIONS:
        __init__
        __str__
        __mul__
        __rmul__
    """

    def __init__(self, 
                 ACR    = 50, 
                 DCR    = 50, 
                 TS     = 200, 
                 OS     = 50):
        
        self.ACR    = ACR
        self.DCR    = DCR
        self.TS     = TS
        self.OS     = OS



    def __str__(self):

        return f"TS: {self.TS}   OS: {self.OS}   ACR: {self.ACR}   DCR: {self.DCR}"
    


    def __mul__(self,other):

        return Speed( TS = int( self.TS * other.TS) 
                     ,OS = int( self.OS * other.OS) 
                     ,ACR = int( self.ACR * other.ACR) 
                     ,DCR = int( self.DCR * other.DCR) )
    


    def __rmul__(self,other):

        return self.__mul__(other)




class ToolCommand:
    """standard tool command according to Jonas' protocol

    ATTRIBUTES:
        M1_ID:
            motor 1 ID (fiber pivoting)
        M1_STEPS:
            motor 1 steps/position
        M2_ID:
            motor 2 ID (fiber delivery)
        M2_STEPS:
            motor 2 steps/position
        M3_ID:
            motor 3 ID (mortar pump)
        M3_STEPS:
            motor 3 steps/position
        PNMTC_CLAMP_ID:
            pneumatic fiber clamp ID
        PNMTC_CLAMP_YN:
            pneumatic fiber clamp on/off
        KNIFE_ID:
            knife delivery ID
        KNIFE_YN:
            knife delivery on/off
        M4_ID:
            motor 4 ID (rotation knife)
        M4_STEPS:
            motor 4 steps/position
        PNMTC_FIBER_ID:
            pneumatic fiber conveyer ID
        PNMTC_FIBER_YN:
            pneumatic fiber conveyer on/off
        TIME_ID:
            time ID
        TIME_TIME:
            current time in milli seconds at EE
        
    FUNCTIONS:
        __def__
        __str__
    """

    def __init__(self,
                 M1_ID          = 0,
                 M1_STEPS       = 0,
                 M2_ID          = 0,
                 M2_STEPS       = 0,
                 M3_ID          = 0,
                 M3_STEPS       = 0,
                 PNMTC_CLAMP_ID = 0,
                 PNMTC_CLAMP_YN = 0,
                 KNIFE_ID       = 0,
                 KNIFE_YN       = 0,
                 M4_ID          = 0,
                 M4_STEPS       = 0,
                 PNMTC_FIBER_ID = 0,
                 PNMTC_FIBER_YN = 0,
                 TIME_ID        = 0,
                 TIME_TIME      = 0):
        
        self.M1_ID          = M1_ID
        self.M1_STEPS       = M1_STEPS
        self.M2_ID          = M2_ID
        self.M2_STEPS       = M2_STEPS
        self.M3_ID          = M3_ID
        self.M3_STEPS       = M3_STEPS
        self.PNMTC_CLAMP_ID = PNMTC_CLAMP_ID
        self.PNMTC_CLAMP_YN = PNMTC_CLAMP_YN
        self.KNIFE_ID       = KNIFE_ID
        self.KNIFE_YN       = KNIFE_YN
        self.M4_ID          = M4_ID
        self.M4_STEPS       = M4_STEPS
        self.PNMTC_FIBER_ID = PNMTC_FIBER_ID
        self.PNMTC_FIBER_YN = PNMTC_FIBER_YN
        self.TIME_ID        = TIME_ID
        self.TIME_TIME      = TIME_TIME



    def __str__(self):

        return  f"M1: {self.M1_ID}, {self.M1_STEPS}   M2: {self.M2_ID}, {self.M2_STEPS}   M3: {self.M3_ID}, {self.M3_STEPS}   "\
                f"P_C: {self.PNMTC_CLAMP_ID}, {self.PNMTC_CLAMP_YN}   KN: {self.KNIFE_ID}, {self.KNIFE_YN}   "\
                f"M4: {self.M4_ID}, {self.M4_STEPS}   P_F: {self.PNMTC_FIBER_ID}, {self.PNMTC_FIBER_YN}   "\
                f"TIME: {self.TIME_ID}, {self.TIME_TIME}"





class QEntry:
    """standard 159 byte command queue entry for TCP robot according to the protocol running on the robot
    
    ATTRIBUTES:
        ID: 
            command ID, list number in robot internal queue
        MT:
            type of movement or special command (L = linear, J = joint, C = circular, S = stop after current movement
            & delete robot internal queue, E = end TCP protocol on robot)
        PT:
            position type, type of rotation given (E = Euler angles, Q = quaternion, A = axis positioning)
        COOR_1:
            coordinates of the first given point
        COOR_2:
            coordinates of the second given point
        SV:
            speed vector for given movement
        SBT:
            time to calculate speed by
        SC:
            speed command, set movement speed by movement time (SBT) or speed vector (SV), (T = time, V = vector)
        Z:
            zone, endpoint precision
        TOOL:
            tool command in Jonas' standard format
        
    FUNCTIONS:
        __init__
        __str__
    """

    def __init__(self,
                 ID     = 0,
                 MT     = "L",
                 PT     = "E",
                 COOR_1 = None,
                 COOR_2 = None,
                 SV     = None,
                 SBT    = 0,
                 SC     = "V",
                 Z      = 10,
                 TOOL   = None):
        
        self.ID     = ID
        self.MT     = MT
        self.PT     = PT
        self.SBT    = SBT
        self.SC     = SC
        self.Z      = Z

        # handle those beasty mutables
        self.COOR_1 = Coor()        if (COOR_1 == None) else COOR_1
        self.COOR_2 = Coor()        if (COOR_2 == None) else COOR_2
        self.SV     = Speed()       if (SV == None)     else SV
        self.TOOL   = ToolCommand() if (TOOL == None)   else TOOL
    


    def __str__(self):
        
        return  f"ID: {self.ID}  MT: {self.MT}  PT: {self.PT} \t|| COOR_1: {self.COOR_1}"\
                f"\n\t\t|| COOR_2: {self.COOR_2}"\
                f"\n\t\t|| SV:     {self.SV} \t|| SBT: {self.SBT}   SC: {self.SC}   Z: {self.Z}"\
                f"\n\t\t|| TOOL:   {self.TOOL}"





class Queue:
    """QEntry-based list incl. data handling
    
        ATTRIBUTES:
            queue:
                a list of QEntry elements, careful: list index does not match QEntry.ID

        FUNCTIONS:
            __init__
            __str__
            __getitem__
            __len__

            display:
                returns queue as a str list (uses __str__ of QEntry)
            increment:
                increments all QEntry.ID to handle DC commands send before the queue
            add:
                adds a new QEntry to queue, checks if QEntry.ID makes sense, places QEntry in queue according to the ID given
            clear:
                deletes single or multiple QEntry from queue, adjusts following ID accordingly
            popFirstItem:
                returns and deletes the QEntry at index 0
    """

    def __init__(self,queue = None):

        self.queue = [] if (queue == None) else queue
    


    def __str__(self):

        if(len(self.queue) != 0):
            i   = 0
            ans = ''
            for x in self.queue:
                i   += 1
                ans += f"Element {i}: {x}\n"
            return ans
        
        else: return "Queue is empty!"



    def __getitem__(self,i):

        try:                return self.queue[i]
        except IndexError:  return None


    
    def __len__(self):

        return len(self.queue)



    def display(self):
        """ returns queue as a str list (uses __str__ of QEntry) """

        if(len(self.queue) != 0):
            ans = []
            for x in self.queue: ans.append( str(x) )
            return ans
        
        else:
            return ["Queue is empty!"]



    def increment(self):
        """ increments all QEntry.ID to handle DC commands send before the queue """

        for i in self.queue:
            i.ID += 1



    def add(self, newEntry):
        """ adds a new QEntry to queue, checks if QEntry.ID makes sense, places QEntry in queue according to the ID given """

        lastItem = len(self.queue) - 1
        
        if(lastItem < 0):
            global SC_curr_comm_id

            newEntry.ID = SC_curr_comm_id
            self.queue.append(newEntry)
            return None
        
        lastID = self.queue[lastItem].ID

        if( (newEntry.ID == 0) or (newEntry.ID > lastID) ):
            newEntry.ID = lastID + 1
            self.queue.append(newEntry)

        elif (newEntry.ID < 0):
            return ValueError
        
        else:
            frontSkip = newEntry.ID - self.queue[0].ID
            self.queue.insert(frontSkip,newEntry)
            for i in range(lastItem + 1 - frontSkip):
                i += 1
                self.queue[i + frontSkip].ID += 1

        return None
    


    def clear(self, all = True, ID = ''):
        """ deletes single or multiple QEntry from queue, adjusts following ID accordingly """

        if(all):
            self.queue = []
            return self.queue

        ids     = re.findall('\d+',ID)
        idNum   = len(ids)
        firstID = self.queue[0].ID
        lastID  = self.queue[len(self.queue) - 1].ID
        
        match idNum:

            case 1:
                id1 = int(ids[0])

                if( (id1 < firstID) or (id1 > lastID) ):  return ValueError

                i = 0
                for entry in self.queue:
                    if(entry.ID == id1):    break
                    else:                   i += 1
                
                self.queue.__delitem__(i)
                while (i < len(self.queue)):
                    self.queue[i].ID -= 1
                    i += 1

            case 2:
                id1,id2 = int(ids[0]), int(ids[1])

                if( (id1 < firstID) 
                     or (id1 > lastID) 
                     or (id2 < id1) 
                     or (id2 > lastID) 
                     or (ID.find('..') == -1) ):
                    return ValueError
                
                idDist = (id2 - id1) + 1
                i = 0
                for entry in self.queue:
                    if(entry.ID == id1):    break
                    else:                   i += 1
                
                for n in range(idDist):
                    self.queue.__delitem__(i)
                
                while ( i < len(self.queue) ):
                    self.queue[i].ID -= idDist
                    i += 1

            case _: 
                return ValueError      

        return self.queue 



    def popFirstItem(self):        
        """ returns and deletes the QEntry at index 0"""

        try:                entry = self.queue[0]
        except IndexError:  return IndexError
        self.queue.__delitem__(0)
        return entry





class RoboTelemetry:
    """ class used to store the standard 36 byte telemetry data comming from the robot """

    def __init__(self,
                TOOL_SPEED  = 0.0,
                ID          = -1,
                X           = 0.0,
                Y           = 0.0,
                Z           = 0.0,
                X_ORI       = 0.0,
                Y_ORI       = 0.0,
                Z_ORI       = 0.0,
                EXT         = 0.0):
        
        self.TOOL_SPEED = TOOL_SPEED
        self.ID         = ID
        self.X          = X
        self.Y          = Y
        self.Z          = Z
        self.X_ORI      = X_ORI
        self.Y_ORI      = Y_ORI
        self.Z_ORI      = Z_ORI
        self.EXT        = EXT

    def __str__(self):

        return  f"ID: {self.ID}   X: {self.X}   Y: {self.Y}   Z: {self.Z}   Rx: {self.X_ORI}   Ry: {self.Y_ORI}   Rz: {self.Z_ORI}   "\
                f"EXT:   {self.EXT}   TOOL_SPEED: {self.TOOL_SPEED}"






class TCPIP:
    """ setup class for TCP/IP connection, provides all functions concerning the connection, cement pump communication not yet implemented

    ATTRIBUTES:
        IP:
            endpoint IP address
        PORT:
            endpoint port nummber
        C_TOUT:
            timeout for connection attempts to endpoint
        RW_TOUT:
            timeout for reading from or writing to endpoint
        R_BL:
            data block length to read
        W_BL:
            data block length to write
    
    FUNCTIONS:
        __init__
        __str__
        connect:
            tries to connect to the IP and PORT given, returns errors if not possible
        send: 
            sends data to server, packing according to robots protocol, additional function for pump needed
        receive:
            receives and unpacks data from robot, addtional function needed for pump
        close:
            close TCP/IP connection
    """
    

    def __init__(self, 
                 IP         = "",
                 PORT       = 0,
                 C_TOUT     = 1.0,
                 RW_TOUT    = 1,
                 R_BL       = 0,
                 W_BL       = 0):
        
        self.IP         = IP
        self.PORT       = PORT
        self.C_TOUT     = C_TOUT
        self.RW_TOUT    = RW_TOUT
        self.R_BL       = R_BL
        self.W_BL       = W_BL

        self.connected  = 0
        self.sock       = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.telemetry  = RoboTelemetry()
    

    def __str__(self):

        return  f"IP: {self.IP}   PORT: {self.PORT}   C_TOUT: {self.C_TOUT}   RW_TOUT: {self.RW_TOUT}   "\
                f"R_BL: {self.R_BL}   W_BL: {self.W_BL}"
    


    def setParams(self,paramDict):
        if(self.connected): 
            raise PermissionError('params not changeable while connected to server!')
        
        self.IP         = paramDict["IP"]
        self.PORT       = paramDict["PORT"]
        self.C_TOUT     = paramDict["CTOUT"]
        self.RW_TOUT    = paramDict["RWTOUT"]
        self.R_BL       = paramDict["R_BL"]
        self.W_BL       = paramDict["W_BL"]



    def connect(self):
        """ tries to connect to the IP and PORT given, returns errors if not possible """

        server_address = (self.IP, self.PORT)
        self.sock.settimeout(self.C_TOUT)

        try:
            self.sock.connect(server_address)
            self.connected = 1
            self.sock.settimeout(self.RW_TOUT)
            return True,server_address
        
        except TimeoutError:
            self.connected = 0
            return TimeoutError,server_address
        
        except ConnectionRefusedError:
            self.connected = 0
            return ConnectionError,server_address
        


    def send(self,QEntry):
        """ sends data to server, packing according to robots protocol, additional function for pump needed """

        message = []        
        try:
            message = struct.pack('<iccffffffffffffffffiiiiiciiiiiiiiiiiiiiiii'
                                  ,QEntry.ID
                                  ,bytes(QEntry.MT,"utf-8")
                                  ,bytes(QEntry.PT,"utf-8")
                                  ,QEntry.COOR_1.X
                                  ,QEntry.COOR_1.Y
                                  ,QEntry.COOR_1.Z
                                  ,QEntry.COOR_1.X_ori
                                  ,QEntry.COOR_1.Y_ori
                                  ,QEntry.COOR_1.Z_ori
                                  ,QEntry.COOR_1.Q
                                  ,QEntry.COOR_1.EXT
                                  ,QEntry.COOR_2.X
                                  ,QEntry.COOR_2.Y
                                  ,QEntry.COOR_2.Z
                                  ,QEntry.COOR_2.X_ori
                                  ,QEntry.COOR_2.Y_ori
                                  ,QEntry.COOR_2.Z_ori
                                  ,QEntry.COOR_2.Q
                                  ,QEntry.COOR_2.EXT
                                  ,QEntry.SV.ACR
                                  ,QEntry.SV.DCR
                                  ,QEntry.SV.TS
                                  ,QEntry.SV.OS
                                  ,QEntry.SBT
                                  ,bytes(QEntry.SC,"utf-8")
                                  ,QEntry.Z
                                  ,QEntry.TOOL.M1_ID
                                  ,QEntry.TOOL.M1_STEPS
                                  ,QEntry.TOOL.M2_ID
                                  ,QEntry.TOOL.M2_STEPS
                                  ,QEntry.TOOL.M3_ID
                                  ,QEntry.TOOL.M3_STEPS
                                  ,QEntry.TOOL.PNMTC_CLAMP_ID
                                  ,QEntry.TOOL.PNMTC_CLAMP_YN
                                  ,QEntry.TOOL.KNIFE_ID
                                  ,QEntry.TOOL.KNIFE_YN
                                  ,QEntry.TOOL.M4_ID
                                  ,QEntry.TOOL.M4_STEPS
                                  ,QEntry.TOOL.PNMTC_FIBER_ID
                                  ,QEntry.TOOL.PNMTC_FIBER_YN
                                  ,QEntry.TOOL.TIME_ID
                                  ,QEntry.TOOL.TIME_TIME)
            
            if(len(message) != self.W_BL):  return ValueError,len(message) 
            
            try:                self.sock.sendall(message)
            except OSError:     return OSError,None

            return True,len(message)
        
        except Exception as err:
            return err,None



    def receive(self):
        """ receives and unpacks data from robot, addtional function needed for pump """

        data = ""

        try:
            while ( len(data) < self.R_BL ):        data = self.sock.recv(self.R_BL)
        except OSError or TimeoutError as err:      return err,data,False

        if len(data) != self.R_BL:       return ValueError,data,False
        else:
            self.telemetry.TOOL_SPEED  = struct.unpack('<f',data[0:4])[0]
            self.telemetry.ID          = struct.unpack('<i',data[4:8])[0]
            self.telemetry.X           = struct.unpack('<f',data[8:12])[0]
            self.telemetry.Y           = struct.unpack('<f',data[12:16])[0]
            self.telemetry.Z           = struct.unpack('<f',data[16:20])[0]
            self.telemetry.X_ORI       = struct.unpack('<f',data[20:24])[0]
            self.telemetry.Y_ORI       = struct.unpack('<f',data[24:28])[0]
            self.telemetry.Z_ORI       = struct.unpack('<f',data[28:32])[0]
            self.telemetry.EXT         = struct.unpack('<f',data[32:36])[0]
            return self.telemetry,data,True
            


    def close(self):
        """ close TCP connection """
        
        self.sock.close()
        self.connected  = 0
        self.sock       = socket.socket(socket.AF_INET, socket.SOCK_STREAM)




#############################################################################################
#                                    FUNCTIONS
#############################################################################################

# def txtEntryToFloat(txt = ''):
#     """ used to convert QLineEdit entries into float, returns error if pattern is not matched """
#     if(txt == ''):
#         return ValueError
#     res = ''
#     try:
#         res = re.findall('\d+[,.]\d+',txt)[0]
#     except IndexError:
#         try:
#             res = re.findall('\d+',txt)[0]
#         except IndexError:
#             return IndexError
#     res = res.replace(',','.')
#     return float(res)



def preCheckGcodeFile(txt=''):
    """ extracts the number of GCode commands and the filament length from text """
    
    try:
        if (txt == ''):    return 0, 0, 'empty'

        rows            = txt.split('\n')
        X               = 0.0
        Y               = 0.0
        commNum         = 0
        filamentLength  = 0.0

        for row in rows:
            if ( len( re.findall('^G\d+', row) ) > 0 ):   commNum += 1

            Y_new = float( reShort('Y\d+[,.]\d+', row, Y, 'Y\d+')[0] )
            X_new = float( reShort('X\d+[,.]\d+', row, X, 'X\d+')[0] )

            # do the Pythagoras for me, baby
            filamentLength += m.sqrt( m.pow( (X_new - X), 2 ) + m.pow( (Y_new - Y), 2 ) )

            X = X_new
            Y = Y_new

    except Exception as e:
        return None, None, e

    return commNum, filamentLength, ''



def reShort(regEx,txt,default,fallbackRegEx = ''):
    """ tries 2 regular expressions on expressions like 'X1.23 Y4.56', 
        returns first match without the leading letter (e.g. '1.23' for '\d+[.,]\d+'),
        returns default value and 'False' if no match occurs """
    
    try:    ans = re.findall(regEx,txt)[0][1:]

    except IndexError:
        if(fallbackRegEx == ''):    return default, False
        try:                        ans = re.findall(fallbackRegEx,txt)[0][1:]
        except IndexError:          return default, False

    return ans, True



def gcodeG1ToQEntry(pos, speed, zone, txt = ''):
    """ converts a single line of GCode G1 command to a QEntry, can be used in loops for multiline code """
    
    entry = QEntry(ID=0, COOR_1=pos, SV=speed, Z=zone)
            
    X,res                       = reShort('X\d+[,.]\d+', txt, pos.X, 'X\d+')
    if(res): entry.COOR_1.X     = float(X.replace(',','.'))

    Y,res                       = reShort('Y\d+[,.]\d+', txt, pos.Y, 'Y\d+')
    if(res): entry.COOR_1.Y     = float(Y.replace(',','.'))

    Z,res                       = reShort('Z\d+[,.]\d+', txt, pos.Z, 'Z\d+')
    if(res): entry.COOR_1.Z     = float(Z.replace(',','.'))
    
    F,res                       = reShort('F\d+[,.]\d+', txt, speed.TS, 'F\d+')
    if(res):
        F                       = float(F.replace(',','.'))
        entry.SV.TS             = int(F * IO_fr_to_ts)

    return entry



def rapidToQEntry(txt = ''):
    """ converts a single line of MoveL, MoveJ or MoveC command (no Offs or Reltool) to a QEntry, can be used in loops for multiline code 
        returns entry and any Exceptions"""
    
    entry = QEntry(ID=0, PT='Q')

    try:
        entry.MT            = re.findall('^Move[J,L,C]', txt, 0)[0][4]
        res_coor            = re.findall('\d+\.\d+',txt)
        res_speed           = re.findall('\d+,\d+,\d+,\d+(?=\]],z)',txt)[0]
        res_speed           = re.findall('\d+',res_speed)

        entry.COOR_1.X      = float(res_coor[0])
        entry.COOR_1.Y      = float(res_coor[1])
        entry.COOR_1.Z      = float(res_coor[2])
        entry.COOR_1.X_ori  = float(res_coor[3])
        entry.COOR_1.Y_ori  = float(res_coor[4])
        entry.COOR_1.Z_ori  = float(res_coor[5])
        entry.COOR_1.Q      = float(res_coor[6])
        entry.SV.TS         = int(res_speed[0])
        entry.SV.OS         = int(res_speed[1])
        entry.SV.ACR        = int(res_speed[2])
        entry.SV.DCR        = int(res_speed[3])

        zone,res            = reShort('z\d+',txt,10)
        entry.Z             = float(zone)

        # for later, if tool is implemented
        tool                = reShort(',[^,]*$',txt,'tool0')
    
    except Exception as e:
        return None,e
    
    return entry,None



def createLogfile():
    """ defines and creates a logfile (and folder if necessary), which carries its creation datetime in the title """

    try:
        desk    = os.environ['USERPROFILE']
        logpath = desk / Path("Desktop/PRINT_py_log")
        logpath.mkdir(parents=True,exist_ok=True)

        logpath = logpath / Path(str(datetime.now().strftime('%Y-%m-%d_%H%M%S')) + ".txt")
        text    = f"{datetime.now().strftime('%Y-%m-%d_%H%M%S')}  GNRL: program booting, starting GUI...\n"

        logfile = open(logpath,'x')
        logfile.write(text)
        logfile.close()

    except Exception as e:
        print(f"Exception occured during log file creation: {e}")
        return None

    return(logpath)



def showOnTerminal(txt):
    """ puts entries in terminal list an keep its length below TERM_maxLen"""
    global TERM_log
    global TERM_maxLen

    TERM_log.append(txt)

    if ( len(TERM_log) > TERM_maxLen ):   TERM_log.__delitem__(0)
    




#############################################################################################
#                                    GLOBALS
#############################################################################################

############################ global constants
# defaut connection settings (the byte length for writing to the robot wont be user setable
# for safety reasons, it can only be changed here, but only if you know what your doing!)
DEF_TCP_ROB =      { "IP":       "192.168.125.1"
                    ,"PORT":     4196
                    ,"CTOUT":    60
                    ,"RWTOUT":   1
                    ,"R_BL":     36
                    ,"W_BL":     159 }

DEF_TCP_PUMP1 =    { "IP":       ""
                    ,"PORT":     "COM3"
                    ,"CTOUT":    0
                    ,"RWTOUT":   0
                    ,"R_BL":     0
                    ,"W_BL":     0  }

DEF_TCP_PUMP2 =    { "IP":       ""
                    ,"PORT":     "COM4"
                    ,"CTOUT":    0
                    ,"RWTOUT":   0
                    ,"R_BL":     0
                    ,"W_BL":     0  }

# default user settings
DEF_DC_SPEED        = Speed()
DEF_IO_ZONE         = 0
DEF_IO_FR_TO_TS     = 0.0
DEF_PRIN_SPEED      = Speed()
DEF_ROBO_COMM_FR    = 10
DEF_SC_VOL_PER_E    = 0.0


############################ global variables
DC_curr_zero        = Coor()
DC_speed            = copy.deepcopy(DEF_DC_SPEED)

IO_zone             = DEF_IO_ZONE
IO_curr_filepath    = None
IO_fr_to_ts         = DEF_IO_FR_TO_TS

PRIN_speed          = copy.deepcopy(DEF_PRIN_SPEED)

PUMP1_tcpip         = TCPIP( DEF_TCP_PUMP1["IP"]
                            ,DEF_TCP_PUMP1["PORT"]
                            ,DEF_TCP_PUMP1["CTOUT"]
                            ,DEF_TCP_PUMP1["RWTOUT"]
                            ,DEF_TCP_PUMP1["R_BL"]
                            ,DEF_TCP_PUMP1["W_BL"])
PUMP1_speed         = 0

PUMP2_tcpip         = TCPIP( DEF_TCP_PUMP2["IP"]
                            ,DEF_TCP_PUMP2["PORT"]
                            ,DEF_TCP_PUMP2["CTOUT"]
                            ,DEF_TCP_PUMP2["RWTOUT"]
                            ,DEF_TCP_PUMP2["R_BL"]
                            ,DEF_TCP_PUMP2["W_BL"])

ROBO_tcpip          = TCPIP( DEF_TCP_ROB["IP"]
                            ,DEF_TCP_ROB["PORT"]
                            ,DEF_TCP_ROB["CTOUT"]
                            ,DEF_TCP_ROB["RWTOUT"]
                            ,DEF_TCP_ROB["R_BL"]
                            ,DEF_TCP_ROB["W_BL"])
ROBO_comm_fr        = DEF_ROBO_COMM_FR
ROBO_comm_queue     = Queue()

SC_vol_per_e        = DEF_SC_VOL_PER_E
SC_curr_comm_id     = 1
SC_queue            = Queue()
SC_qProcessing      = False

STT_pos             = Coor()
STT_toolSpeed       = 0
STT_robo_comm_id    = 0

TERM_log            = []
TERM_maxLen         = 2000