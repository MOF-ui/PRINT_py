#   This work is licensed under Creativ Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
#   (https://creativecommons.org/licenses/by-sa/4.0/). Feel free to use, modify or distribute this code as  
#   far as you like, so long as you make anything based on it publicly avialable under the same license.


#######################################     IMPORTS      #####################################################

# python standard libraries
import sys
import copy
from pathlib import Path
from datetime import datetime


# PyQt stuff
from PyQt5.QtCore import QTimer, QMutex, QThread
from PyQt5.QtWidgets import QApplication, QMainWindow


# import PyQT UIs (converted from .ui to .py)
from ui.UI_mainframe_v5 import Ui_MainWindow


# import my own libs
from libs.PRINT_win_dialogs import strdDialog, fileDialog
from libs.PRINT_threads import RoboCommWorker,PumpCommWorker
import libs.PRINT_data_utilities as UTIL




####################################### MAINFRAME CLASS  #####################################################

class Mainframe(QMainWindow, Ui_MainWindow):
    """ main UI of PRINT_py (further details pending) """
    
    logpath = ''




    #####################################################################################################
    #                                           SETUP                                                   #
    #####################################################################################################
    
    def __init__(self,lpath = None,parent=None):
        """ setup main window """

        super().__init__(parent)
        
        self.setupUi(self)
        self.setWindowTitle("---   PRINT_py  ---")
       

        if(lpath is None):
            logWarning = strdDialog('No path for logfile!\n\nPress OK to continue anyways or\n\
                                     Cancel to exit the program.'
                                    ,'LOGFILE ERROR')
            logWarning.exec()

            if( logWarning.result() == 0 ):
                # suicide after the actual .exec is finished, exit without chrash
                QTimer.singleShot(0, self.close)

        else:
            self.logpath = lpath
            self.logEntry('GNRL','GUI running.')

        self.logEntry('GNRL','init threading...')
        self.connectThreads()

        self.logEntry('GNRL','connecting mainsignals...')
        self.connectMainSignals()
        
        self.logEntry('GNRL','load default settings...')
        self.loadDefaults()
        
        self.logEntry('GNRL','connect to Robot...') 
        res = self.connectTCP(1)

        if(res == False):
            self.logEntry('GNRL','failed, exiting...')
            # suicide after the actual .exec is finished, exit without chrash
            QTimer.singleShot(0, self.close)

        else:
            self.roboCommThread.start() 
            self.pumpCommThread.start()
            self.setWatchdog()
            self.logEntry('GNRL','setup finished.\n')






    def connectMainSignals(self):
        """ create signal-slot-links"""

        self.DC_btt_xPlus.pressed.connect       ( lambda: self.sendDCCommand('X','+') )
        self.DC_btt_xMinus.pressed.connect      ( lambda: self.sendDCCommand('X','-') )
        self.DC_btt_yPlus.pressed.connect       ( lambda: self.sendDCCommand('Y','+') )
        self.DC_btt_yMinus.pressed.connect      ( lambda: self.sendDCCommand('Y','-') )
        self.DC_btt_zPlus.pressed.connect       ( lambda: self.sendDCCommand('Z','+') )
        self.DC_btt_zMinus.pressed.connect      ( lambda: self.sendDCCommand('Z','-') )
        self.DC_btt_extPlus.pressed.connect     ( lambda: self.sendDCCommand('EXT','+') )
        self.DC_btt_extMinus.pressed.connect    ( lambda: self.sendDCCommand('EXT','-') )
        self.DC_btt_xyzZero.pressed.connect     ( lambda: self.setZero([1,2,3]) )
        self.DC_btt_extZero.pressed.connect     ( lambda: self.setZero([8]) )
        self.DC_btt_home.pressed.connect        (self.homeCommand)

        self.NC_btt_xyzSend.pressed.connect     ( lambda: self.sendNCCommand([1,2,3]) )
        self.NC_btt_xyzExtSend.pressed.connect  ( lambda: self.sendNCCommand([1,2,3,8]) )
        self.NC_btt_orientSend.pressed.connect  ( lambda: self.sendNCCommand([4,5,6]) )
        self.NC_btt_orientZero.pressed.connect  ( lambda: self.setZero([4,5,6]) )

        self.IO_btt_newFile.pressed.connect     (self.openFile)
        self.IO_btt_loadFile.pressed.connect    (self.loadFile)
        self.IO_btt_addByID.pressed.connect     ( lambda: self.loadFile(lf_adID = True) )
        self.IO_btt_xyzZero.pressed.connect     ( lambda: self.setZero([1,2,3]) )
        self.IO_btt_extZero.pressed.connect     ( lambda: self.setZero([8]) )

        self.SCTRL_btt_forcedStop.pressed.connect           ( lambda: self.forcedStopCommand('S') )
        self.SCTRL_btt_startQProcessing.pressed.connect     ( self.startSCTRLQueue )
        self.SCTRL_btt_holdQProcessing.pressed.connect      ( self.stopSCTRLQueue )
        self.SCTRL_btt_addSIB1_atFront.pressed.connect      ( lambda: self.addSIB(1) )
        self.SCTRL_btt_addSIB1_atEnd.pressed.connect        ( lambda: self.addSIB(1, atEnd = True) )
        self.SCTRL_btt_addSIB1_atFront.pressed.connect      ( lambda: self.addSIB(2) )
        self.SCTRL_btt_addSIB1_atFront.pressed.connect      ( lambda: self.addSIB(2, atEnd = True) )
        self.SCTRL_btt_clrQ.pressed.connect                 ( lambda: self.clrQueue(partial = False) )
        self.SCTRL_btt_clrByID.pressed.connect              ( lambda: self.clrQueue(partial = True) )

        self.SGLC_btt_gcodeSglComm.pressed.connect          (self.addGcodeSgl)
        self.SGLC_btt_rapidSglComm.pressed.connect          (self.addRapidSgl)
        self.SGLC_btt_gcodeSglComm_addByID.pressed.connect  ( lambda: self.addGcodeSgl( atID = True
                                                                                       ,ID = self.SGLC_num_gcodeSglComm_addByID.value()) )
        self.SGLC_btt_rapidSglComm_addByID.pressed.connect  ( lambda: self.addRapidSgl( atID = True
                                                                                       ,ID = self.SGLC_num_rapidSglComm_addByID.value()) )
        
        self.SET_btt_apply.pressed.connect                  (self.applySettings)
        self.SET_btt_default.pressed.connect                (self.loadDefaults)

        # self.TCP_ROB_btt_reconn.pressed.connect             ( lambda: self.connectTCP(1) )
        self.TCP_ROB_btt_discon.pressed.connect             ( lambda: self.disconnectTCP(1) )
        # self.TCP_PUMP1_btt_reconn.pressed.connect           ( lambda: self.connectTCP(2) )
        self.TCP_PUMP1_btt_discon.pressed.connect           ( lambda: self.disconnectTCP(2) )
        # self.TCP_PUMP2_btt_reconn.pressed.connect           ( lambda: self.connectTCP(3) )
        self.TCP_PUMP2_btt_discon.pressed.connect           ( lambda: self.disconnectTCP(3) )
        
        self.TERM_btt_gcodeInterp.pressed.connect           (self.sendGcodeCommand)
        self.TERM_btt_gcodeInterp.pressed.connect           (self.sendRapidCommand)
        # self.action_Exit.triggered.connect(self.close)






    def loadDefaults(self):
        """ load default settings to settings display """
        
        self.TCP_num_commForerun.setValue       ( UTIL.DEF_ROBO_COMM_FR )

        self.SET_float_volPerE.setValue         ( UTIL.DEF_SC_VOL_PER_E )
        self.SET_float_frToMms.setValue         ( UTIL.DEF_IO_FR_TO_TS )

        self.SET_num_zone.setValue              ( UTIL.DEF_IO_ZONE )
        self.SET_num_transSpeed_dc.setValue     ( UTIL.DEF_PRIN_SPEED.TS )
        self.SET_num_orientSpeed_dc.setValue    ( UTIL.DEF_PRIN_SPEED.OS )
        self.SET_num_accelRamp_dc.setValue      ( UTIL.DEF_PRIN_SPEED.ACR )
        self.SET_num_decelRamp_dc.setValue      ( UTIL.DEF_PRIN_SPEED.DCR )
        self.SET_num_transSpeed_print.setValue  ( UTIL.DEF_DC_SPEED.TS )
        self.SET_num_orientSpeed_print.setValue ( UTIL.DEF_DC_SPEED.OS )
        self.SET_num_accelRamp_print.setValue   ( UTIL.DEF_DC_SPEED.ACR )
        self.SET_num_decelRamp_print.setValue   ( UTIL.DEF_DC_SPEED.DCR )







    def connectTCP(self,TCPslot = 0):
        """slot-wise connection management, mostly to shrink code length, maybe more functionality later"""

        css = ("border-radius: 25px; \
                background-color: #00aaff;")

        match TCPslot:
            case 1:  
                res,conn = UTIL.ROBO_tcpip.connect()
                self.TCP_ROB_indi_connected.setStyleSheet(css)
            case 2:  
                res,conn = UTIL.PUMP1_tcpip.connect()
                self.TCP_ROB_indi_connected.setStyleSheet(css)
            case 3:  
                res,conn = UTIL.PUMP2_tcpip.connect()
                self.TCP_ROB_indi_connected.setStyleSheet(css)
        
        if (res == True):
            self.logEntry('CONN',f"connected to {conn[0]} at {conn[1]}.")
            return True
        
        elif (res == TimeoutError):             self.logEntry('CONN',f"timed out while trying to connect {conn[0]} at {conn[1]} .")
        elif (res == ConnectionRefusedError):   self.logEntry('CONN',f"server {conn[0]} at {conn[1]} refused the connection.")
        else:                                   self.logEntry('CONN',f"connection to {conn[0]} at {conn[1]} failed!")
        
        return False







    def disconnectTCP(self,TCPslot = 0):
        """ disconnect works, reconnect crashes the app, problem probably lies here
            should also send E command to robot on disconnect """

        css = ("border-radius: 25px; \
                background-color: #4c4a48;")

        match TCPslot:
            case 1:  
                self.killWatchdog(1)
                self.receiveWorker.pause()
                UTIL.ROBO_tcpip.close()

                self.logEntry('CONN',f"user disconnected robot.")
                self.TCP_ROB_indi_connected.setStyleSheet(css)
            case 2:  
                UTIL.PUMP1_tcpip.close()
                self.TCP_ROB_indi_connected.setStyleSheet(css)
            case 3:  
                UTIL.PUMP2_tcpip.close()
                self.TCP_ROB_indi_connected.setStyleSheet(css)
        






    #####################################################################################################
    #                                          THREADS                                                  #
    #####################################################################################################

    def connectThreads(self):
        """load all threads from PRINT_threads and set signal-slot-connections"""

        self.roboCommThread = QThread()
        self.roboCommWorker = RoboCommWorker()
        self.roboCommWorker.moveToThread        (self.roboCommThread)
        self.roboCommThread.started.connect     (self.roboCommWorker.run)
        self.roboCommThread.finished.connect    (self.roboCommWorker.stop)
        self.roboCommThread.finished.connect    (self.roboCommWorker.deleteLater)
        self.roboCommWorker.logError.connect    (self.logEntry)
        self.roboCommWorker.dataUpdated.connect ( lambda: self.resetWatchdog(1) )
        self.roboCommWorker.dataUpdated.connect (self.posUpdate)
        self.roboCommWorker.queueEmtpy.connect  (self.stopSCTRLQueue)
        self.roboCommWorker.sendElem.connect    (self.sendCommand)
        self.roboCommWorker.sendElem.connect    (self.labelUpdate_onSend)

        self.pumpCommThread = QThread()
        self.pumpCommWorker = PumpCommWorker()
        self.pumpCommWorker.moveToThread        (self.pumpCommThread)
        self.pumpCommThread.started.connect     (self.pumpCommWorker.run)
        self.pumpCommThread.finished.connect    (self.pumpCommWorker.stop)
        self.pumpCommThread.finished.connect    (self.pumpCommWorker.deleteLater)
        self.pumpCommWorker.logError.connect    (self.logEntry)
        # self.pumpCommWorker.dataSend.connect    ()
        # self.pumpCommWorker.dataReceived.connect()
    





    def posUpdate(self,rawDataString,pos,toolSpeed,robo_comm_id):

        mutex.lock()
        UTIL.STT_pos            = pos
        UTIL.STT_toolSpeed      = toolSpeed
        UTIL.STT_robo_comm_id   = robo_comm_id
        mutex.unlock()

        self.labelUpdate_onReceive(rawDataString)






    #####################################################################################################
    #                                          WATCHDOGS                                                #
    #####################################################################################################

    def setWatchdog(self):
        """ set Watchdog, just one to check the robots TCP connection for now (receiveWD) at least every 10 sec """

        self.receiveWD = QTimer()
        self.receiveWD.setSingleShot    (True)
        self.receiveWD.setInterval      (10000)
        self.receiveWD.timeout.connect  (lambda: self.watchdogBite(1))

        self.receiveWD.start()
        self.logEntry('WDOG','Watchdog 1 (receiveWD) started.')
        




    def resetWatchdog(self, dognumber=0):
        """ reset the Watchdogs, receiveWD on every newly received data block """

        match dognumber:
            case 1:   self.receiveWD.start()
            case _:   self.logEntry('WDOG','Watchdog reset failed, invalid dog number given')





    def watchdogBite(self, dognumber = 0):
        """ close the UI on any biting WD, log info """

        match dognumber:
            case 1:   self.logEntry('WDOG','Watchdog 1 (receiveWD) has bitten!')
            case _:   self.logEntry('WDOG','Watchdog (unidentified) has bitten!')
        self.close()





    def killWatchdog(self, dognumber = 0):
        """ put them to sleep (dont do this to real dogs) """

        match dognumber:
            case 1:   self.receiveWD.stop()
            case _:   pass






    #####################################################################################################
    #                                          SETTINGS                                                 #
    #####################################################################################################

    def applySettings(self):
        """ load default settings to settings display """
        
        UTIL.ROBO_comm_fr       = self.TCP_num_commForerun.getValue()

        UTIL.SC_vol_per_e       = self.SET_float_volPerE.getValue()
        UTIL.IO_fr_to_ts        = self.SET_float_frToMms.getValue()

        UTIL.IO_zone            = self.SET_num_zone.getValue()
        UTIL.PRIN_speed.TS      = self.SET_num_transSpeed_dc.getValue()
        UTIL.PRIN_speed.OS      = self.SET_num_orientSpeed_dc.getValue()
        UTIL.PRIN_speed.ACR     = self.SET_num_accelRamp_dc.getValue()
        UTIL.PRIN_speed.DCR     = self.SET_num_decelRamp_dc.getValue()
        UTIL.DC_speed.TS        = self.SET_num_transSpeed_print.getValue()
        UTIL.DC_speed.OS        = self.SET_num_orientSpeed_print.getValue()
        UTIL.DC_speed.ACR       = self.SET_num_accelRamp_print.getValue()
        UTIL.DC_speed.DCR       = self.SET_num_decelRamp_print.getValue()






    #####################################################################################################
    #                                        LOG FUNCTION                                               #
    #####################################################################################################

    def logEntry(self, source='no source', text=''):
        """ set one-line for log entries, safes A LOT of code """

        if (self.logpath == ''):
            return None

        text = f"{datetime.now().strftime('%Y-%m-%d_%H%M%S ')} {source}: {text}\n"
        self.SET_disp_logEntry.setText(text)

        try:
            logfile = open(self.logpath,'a')
        except FileExistsError:
            pass

        logfile.write(text)
        logfile.close()







    #####################################################################################################
    #                                        QLABEL UPDATES                                             #
    #####################################################################################################

    def labelUpdate_onReceive(self,dataString):
        """ update all QLabels in the UI that may change with newly received data from robot """

        pos         = UTIL.STT_pos
        zero        = UTIL.DC_curr_zero
        robID       = UTIL.STT_robo_comm_id
        comID       = UTIL.SC_curr_comm_id
        try:                    progID = UTIL.SC_queue[0].ID
        except AttributeError:  progID = comID

        self.TCP_ROB_disp_readBuffer.setText    (dataString)  
        self.SCTRL_disp_buffComms.setText       ( str(progID - robID) )
        self.SCTRL_disp_robCommID.setText       ( str(robID) )
        self.SCTRL_disp_progCommID.setText      ( str(comID) )
        self.SCTRL_disp_elemInQ.setText         ( str(len(UTIL.SC_queue)) ) 

        self.DC_disp_x.setText                  ( str(pos.X   - zero.X) )
        self.DC_disp_y.setText                  ( str(pos.Y   - zero.Y) )
        self.DC_disp_z.setText                  ( str(pos.Z   - zero.Z) )
        self.DC_disp_ext.setText                ( str(pos.EXT - zero.EXT) )

        self.NC_disp_x.setText                  ( str(pos.X) )
        self.NC_disp_y.setText                  ( str(pos.Y) )
        self.NC_disp_z.setText                  ( str(pos.Z) )
        self.NC_disp_xOrient.setText            ( str(pos.X_ori) )
        self.NC_disp_yOrient.setText            ( str(pos.Y_ori) )
        self.NC_disp_zOrient.setText            ( str(pos.Z_ori) )
        self.NC_disp_ext.setText                ( str(pos.EXT) )

        self.TERM_disp_tcpSpeed.setText         ( str(UTIL.STT_toolSpeed) )
        self.TERM_disp_robCommID.setText        ( str(robID) )
        self.TERM_disp_progCommID.setText       ( str(comID) )

        self.labelUpdate_onTerminalChange()






    def labelUpdate_onSend(self,entry):
        """ update all UI QLabels that may change when data was send to robot"""

        self.labelUpdate_onQueueChange()
        self.labelUpdate_onTerminalChange()
        self.SCTRL_disp_elemInQ.setText         ( str(len(UTIL.SC_queue)) )

        try:                    self.SCTRL_disp_buffComms.setText   (str(UTIL.SC_queue[0].ID - UTIL.STT_robo_comm_id))
        except AttributeError:  pass






    def labelUpdate_onQueueChange(self):
        """ show when new entries have been successfully placed in or taken from Queue """

        self.SCTRL_arr_queue.clear()
        self.SCTRL_arr_queue.addItems( UTIL.SC_queue.display() )

    



    def labelUpdate_onTerminalChange(self):
        """ show when data was send or received """
        
        self.TERM_arr_terminal.clear()
        self.TERM_arr_terminal.addItems ( UTIL.TERM_log )
        if (self.TERM_chk_autoScroll.isChecked()):  self.TERM_arr_terminal.scrollToBottom()

        self.ICQ_arr_terminal.clear()
        self.ICQ_arr_terminal.addItems  ( UTIL.ROBO_comm_queue.display() )
    



    #####################################################################################################
    #                                            FILE IO                                                #
    #####################################################################################################

    def openFile(self):
        """ prompts the user with a file dialog and estimates printing parameters in given file """

        # get file path and content
        fDialog = fileDialog('select file to load')
        fDialog.exec()

        ans = Path(fDialog.selectedFiles()[0]) if( fDialog.result() ) else None

        if(ans is None):
            self.IO_disp_filename.setText("no file selected")
            UTIL.IO_curr_filepath = None
            return None
        
        file    = open(ans,'r')
        txt     = file.read()
        file.close()

        # get number of commands and filament length
        commNum, filamentLength, res = UTIL.preCheckGcodeFile(txt)

        if(commNum is None):
            self.IO_disp_filename.setText   ('COULD READ FILE!')
            self.logEntry                   ('F-IO', f"Error while opening {ans} file: {res}")
            
            UTIL.IO_curr_filepath = None
            return None

        if(res == 'empty'):
            self.IO_disp_filename.setText('FILE EMPTY!')
            return None
        
        # display data
        filamentVol     = filamentLength * UTIL.SC_vol_per_e
        filamentLength  = round(filamentLength, 3)
        filamentVol     = round(filamentVol, 3)

        self.IO_disp_filename.setText   (ans.name)
        self.IO_disp_commNum.setText    ( str(commNum) )
        self.IO_disp_estimLen.setText   ( str(filamentLength) )
        self.IO_disp_estimVol.setText   ( str(filamentVol) )

        self.logEntry('F-IO', f"Opened new file at {ans}:   {commNum} commands,   {filamentLength}mm filament, {filamentVol}L")

        UTIL.IO_curr_filepath = ans
        return ans
    





    def loadFile(self, lf_adID = False):
        """ reads the file set in self.openFile, adds all readable G1 commands to command queue (at end or at ID) """

        fpath = UTIL.IO_curr_filepath

        if (fpath is None):
            self.IO_lbl_loadFile.setText("... no valid file, not executed")
            return False
        
        # get file type and content
        filetype    = fpath.suffix
        file        = open(fpath,'r')
        txt         = file.read()
        file.close()

        rows = txt.split('\n')

        # iterate over all lines in the file, add valid commands found to command queue
        lineID          = self.IO_num_addByID.value()
        lineID_start    = lineID
        skips           = 0

        for row in rows:

            if (filetype == '.gcode'):
                entry,command = self.addGcodeSgl( atID      = lf_adID
                                                 ,ID        = lineID
                                                 ,fromFile  = True
                                                 ,fileText  = row)

                if(command is None):
                    skips += 1

                elif(command == ValueError):
                    self.IO_lbl_loadFile.setText    ("VALUE ERROR, ABORTED")
                    self.logEntry                   ('F-IO',f"ERROR: file IO from {fpath} aborted! false entry: {entry}")
                    return False
                
                elif(command == '1'):
                    lineID += 1

            else:
                entry = self.addRapidSgl( atID      = lf_adID
                                         ,ID        = lineID
                                         ,fromFile  = True
                                         ,fileText  = row)

                if(entry is None):
                    skips += 1

                elif(entry == ValueError):
                    self.IO_lbl_loadFile.setText    ("VALUE ERROR, ABORTED")
                    self.logEntry                   ('F-IO',f"ERROR: file IO from {fpath} aborted! false entry: {entry}")
                    return False
                
                else:
                    lineID += 1
                    
        self.IO_num_addByID.setValue( lineID )

        if(skips == 0):     self.IO_lbl_loadFile.setText("... conversion successful")
        else:               self.IO_lbl_loadFile.setText(f"... {skips} command(s) skipped (syntax)")
        
        self.logEntry('F-IO', f"Read new file at {fpath}:   {lineID - lineID_start} commands, {skips} skipped due to syntax")
        return True
        







    #####################################################################################################
    #                                         COMMAND QUEUE                                             #
    #####################################################################################################


    def startSCTRLQueue(self):
        """ set UI indicators, send the boring work of timing the command to our trusty threads """

        mutex.lock()
        UTIL.SC_qProcessing = True
        mutex.unlock()
        self.logEntry('SC-Q','queue processing started')

        css = "border-radius: 20px; \
               background-color: #00aaff;"
        self.SCTRL_indi_qProcessing.setStyleSheet   (css)
        self.DC_indi_robotMoving.setStyleSheet      (css)
        self.TCP_indi_qProcessing.setStyleSheet     (css)

        self.labelUpdate_onQueueChange()






    def stopSCTRLQueue(self):
        """ set UI indicators, turn of threads """

        mutex.lock()
        UTIL.SC_qProcessing = False
        mutex.unlock()
        self.logEntry('SC-Q','queue processing stopped')

        css = "border-radius: 20px; \
               background-color: #4c4a48;"
        self.SCTRL_indi_qProcessing.setStyleSheet   (css)
        self.DC_indi_robotMoving.setStyleSheet      (css)
        self.TCP_indi_qProcessing.setStyleSheet     (css)

        self.labelUpdate_onQueueChange()

    




    def addGcodeSgl(self, atID = False, ID = 0, fromFile = False, fileText = ''):
        """ function meant to convert any single gcode lines to QEntry, gets them only from SGLC frame, yet """

        # get text and current position, identify command
        txt     = self.SGLC_entry_gcodeSglComm.toPlainText() \
                  if (not fromFile) \
                  else fileText
        
        command = UTIL.reShort('^G\d+', txt, 0, '^;')[0]
        pos     = copy.deepcopy(UTIL.STT_pos)                    # needs work, should use the Coor of queue entry above
        speed   = copy.deepcopy(UTIL.PRIN_speed)

        # act according to GCode command
        match command:

            case '1':
                entry = UTIL.gcodeG1ToQEntry( pos
                                             ,speed
                                             ,UTIL.IO_zone
                                             ,txt)

            case '28':
                # just create an entry with the speed data, DC_curr_zero is added below anyways
                entry = UTIL.QEntry( ID = 0
                                    ,SV = speed
                                    ,Z  = UTIL.IO_zone)
            
            case '92':
                # not ready, needs to distinguish between G92 for X, Y and Z or G92 for E
                # mutex.lock()
                # DC_curr_zero = pos
                # mutex.unlock()
                return None, command
            
            case ';':
                if(not fromFile):   self.SGLC_entry_gcodeSglComm.setText("leading semicolon interpreted as comment: \n" + txt)
                return None, command
            
            case _:
                if(not fromFile):   self.SGLC_entry_gcodeSglComm.setText("SYNTAX ERROR: \n" + txt)
                return None, None

        # set command ID if given, sorting is done later by "Queue" class
        if(atID): entry.ID = ID

        # add everything relativ to current zero
        entry.COOR_1 += UTIL.DC_curr_zero

        mutex.lock()
        res = UTIL.SC_queue.add(entry)
        mutex.unlock()
        
        if(res == ValueError):
            if(not fromFile):   self.SGLC_entry_gcodeSglComm.setText("VALUE ERROR: \n" + txt)
            return None, ValueError
        
        # update displays
        self.labelUpdate_onQueueChange()
        return entry, command

    




    def addRapidSgl(self,atID = False, ID = 0, fromFile = False, fileText = ''):
        """ function meant to convert all RAPID single lines into QEntry, only SGLC frame, yet """

        # get text and current position, (identify command -- to be added)
        txt         = self.SGLC_entry_rapidSglComm.toPlainText() \
                      if (not fromFile) \
                      else fileText
        
        pos         = copy.deepcopy(UTIL.STT_pos)
        entry       = UTIL.QEntry(ID=-1)
        entry,err   = UTIL.rapidToQEntry(txt)

        if( entry == None ):
            if(not fromFile):   self.SGLC_entry_rapidSglComm.setText(f"SYNTAX ERROR: {err}\n" + txt)
            return None, err
        
        # set command ID if given, sorting is done later by "Queue" class
        if(atID): entry.ID = ID

        # add everything relativ to current zero
        entry.COOR_1 += UTIL.DC_curr_zero

        mutex.lock()
        res = UTIL.SC_queue.add(entry)
        mutex.unlock()

        if(res == ValueError):
            if(not fromFile):   self.SGLC_entry_rapidSglComm.setText("VALUE ERROR: \n" + txt)
            return None, ValueError

        self.labelUpdate_onQueueChange()
        return entry, None
    





    def addSIB(self,number,atEnd = False):
        """ add standard instruction block (SIB) to queue"""

        txt             = self.SIB_entry_sib1.toPlainText() \
                          if (number == 1) \
                          else self.SIB_entry_sib2.toPlainText()

        rows            = txt.split('\n')
        lineID          = UTIL.SC_queue[ (len(UTIL.SC_queue) - 1) ].ID \
                          if(atEnd) \
                          else 1
        lineID_start    = lineID

        for row in rows:
            entry,command = self.addGcodeSgl( atID      = True
                                             ,ID        = lineID
                                             ,fromFile  = True
                                             ,fileText  = row)

            if (command == ValueError):
                if (number == 1):   self.SIB_entry_sib1.setText    (f"VALUE ERROR, ABORTED\n {txt}")
                else:               self.SIB_entry_sib2.setText    (f"VALUE ERROR, ABORTED\n {txt}")

                self.logEntry                   (f"SIB{number}",f"ERROR: SIB command import aborted! false entry: {txt}")
                return False
            
            elif (command is None):
                if (number == 1):   self.SIB_entry_sib1.setText    (f"SYNTAX ERROR\n {txt}")
                else:               self.SIB_entry_sib2.setText    (f"SYNTAX ERROR\n {txt}")
                return False
            
            else:
                lineID += 1
        
        self.logEntry(f"SIB{number}", f"{lineID - lineID_start} SIB lines added")
        return True
    





    def clrQueue(self, partial = False):
        """ delete specific or all items from queue """

        mutex.lock()
        if (partial):   UTIL.SC_queue.clear( all = False
                                            ,ID  = self.SCTRL_entry_clrByID.text())
        else:           UTIL.SC_queue.clear( all = True )
        mutex.unlock()
            
        self.labelUpdate_onQueueChange()
        return True








    #####################################################################################################
    #                                          DC COMMANDS                                              #
    #####################################################################################################

    def homeCommand(self):
        """ sets up a command to drive back to DC_curr_zero, gives it to the actual sendCommand function """

        zero    = copy.deepcopy(UTIL.DC_curr_zero)
        readMT  = self.DC_drpd_moveType.currentText()
        mt      = 'L'  if (readMT == 'JOINT')  else 'J'

        command = UTIL.QEntry( ID       = UTIL.SC_curr_comm_id
                              ,MT       = mt
                              ,COOR_1   = zero
                              ,SV       = UTIL.DC_speed
                              ,Z        = 0)
        
        self.logEntry('DCom','sending DC home command...')
        return self.sendCommand(command, DC = True)
        





    def sendDCCommand(self, axis = '0', dir = '+'):
        """ sets up a command accourding to the DC frames input, gives it to the actual sendCommand function """

        stepWidth = self.DC_sld_stepWidth.value()
        match stepWidth:
            case 1:     pass
            case 2:     stepWidth = 10
            case 3:     stepWidth = 100
            case _:     return ValueError

        if(dir != '+' and dir != '-'):      return ValueError
        if(dir == '-'):                     stepWidth = -stepWidth

        newPos = copy.deepcopy(UTIL.STT_pos)

        match axis:
            case 'X':       newPos.X   += stepWidth
            case 'Y':       newPos.Y   += stepWidth
            case 'Z':       newPos.Z   += stepWidth
            case 'EXT':     newPos.EXT += stepWidth
            case _:         return ValueError
            
        
        readMT  = self.DC_drpd_moveType.currentText()
        mt      = 'L'  if (readMT == 'JOINT')  else 'J'

        command = UTIL.QEntry( ID       = UTIL.SC_curr_comm_id
                              ,MT       = mt
                              ,COOR_1   = newPos
                              ,SV       = UTIL.DC_speed
                              ,Z        = 0)
        
        self.logEntry('DCom',f"sending DC command: ({newPos})")
        return self.sendCommand(command, DC = True)






    def sendNCCommand(self,axis):
        """ sets up a command according to NC absolute positioning, gives it to the actual sendCommand function """

        newPos = copy.deepcopy(UTIL.STT_pos)

        # 7 is a placeholder for Q, which can not be set by hand
        if 1 in axis:   newPos.X     = float(self.NC_float_x.value())
        if 2 in axis:   newPos.Y     = float(self.NC_float_y.value())
        if 3 in axis:   newPos.Z     = float(self.NC_float_z.value())
        if 4 in axis:   newPos.X_ori = float(self.NC_float_xOrient.value())
        if 5 in axis:   newPos.Y_ori = float(self.NC_float_yOrient.value())
        if 6 in axis:   newPos.Z_ori = float(self.NC_float_zOrient.value())
        if 8 in axis:   newPos.EXT   = float(self.NC_float_ext.value())

        readMT  = self.DC_drpd_moveType.currentText()
        mt      = 'L'  if (readMT == 'JOINT')  else 'J'

        command = UTIL.QEntry( ID       = UTIL.SC_curr_comm_id
                              ,MT       = mt
                              ,COOR_1   = newPos
                              ,SV       = UTIL.DC_speed
                              ,Z        = 0)
        
        self.logEntry('DCom',f"sending NC command: ({newPos})")
        return self.sendCommand(command, DC = True)
    




    def sendGcodeCommand(self):
        """ send the GCode interpreter line on the TERM panel to robot """
        
        txt     = self.TERM_entry_gcodeInterp.text()
        type    = UTIL.reShort('^G\d+', txt, 0, '^;')[0]
        pos     = copy.deepcopy(UTIL.STT_pos)                    # needs work, should use the Coor of queue entry above
        speed   = copy.deepcopy(UTIL.DC_speed)

        # act according to GCode command
        match type:

            case '1':
                command = UTIL.gcodeG1ToQEntry( pos
                                               ,speed
                                               ,UTIL.IO_zone
                                               ,txt)

            case '28':
                # just create an entry with the speed data, DC_curr_zero is added below anyways
                command = UTIL.QEntry( ID = 0
                                      ,SV = speed
                                      ,Z  = UTIL.IO_zone)
            
            case '92':
                # not ready, needs to distinguish between G92 for X, Y and Z or G92 for E
                # mutex.lock()
                # DC_curr_zero = pos
                # mutex.unlock()
                return None, type
            
            case ';':
                self.TERM_entry_gcodeInterp.setText("leading semicolon interpreted as comment: \n" + txt)
                return None, type
            
            case _:
                self.TERM_entry_gcodeInterp.setText("SYNTAX ERROR: \n" + txt)
                return None, None

        # add everything relativ to current zero
        command.COOR_1 += UTIL.DC_curr_zero
        
        self.logEntry('DCom',f"sending GCode DC command: ({command})")
        return self.sendCommand(command, DC = True), type






    def sendRapidCommand(self):
                # get text and current position, (identify command -- to be added)

        txt         = self.TERM_entry_rapidInterp.text()
        pos         = copy.deepcopy(UTIL.STT_pos)
        command     = UTIL.QEntry(ID=-1)
        command,err = UTIL.rapidToQEntry(txt)

        if( command == None ):
            self.TERM_entry_rapidInterp.setText(f"SYNTAX ERROR: {err}\n" + txt)
            return None, err

        # add everything relativ to current zero
        command.COOR_1 += UTIL.DC_curr_zero
        
        self.logEntry('DCom',f"sending RAPID DC command: ({command})")
        return self.sendCommand(command, DC = True), None






    def forcedStopCommand(self):
        """ sets up non-moving-type commands, gives it to the actual sendCommand function """
        
        command = UTIL.QEntry( ID = 0
                              ,MT = 'S')
        
        FSWarning = strdDialog('WARNING!\n\nRobot will stop after current movement!\n\
                                OK to delete buffered commands on robot\n\
                                Cancel to contuinue queue processing.'
                                ,'FORCED STOP COMMIT')
        FSWarning.exec()

        if(FSWarning.result()):
            self.logEntry('SysC',f"FORCED STOP (user committed).")
            return self.sendCommand(command, DC = True)
        
        else:
            self.logEntry('SysC',f"user denied FS-Dialog, continuing...")
            return None
    





    def robotStopCommand(self, directly = True):

        command = UTIL.QEntry( ID = 0
                              ,MT = 'E')
        
        if(directly):
            self.logEntry('SysC',"sending robot stop command directly")
            return self.sendCommand(command, DC = True)
        else:
            UTIL.SC_queue.add(command)
            self.logEntry('SysC',"added robot stop command to queue")
            return command








    #####################################################################################################
    #                                         SEND COMMANDS                                             #
    #####################################################################################################
    
    def sendCommand(self,command, DC = False):
        """ actual sendCommand function, uses the TCPIP class from utilies, handles errors (not done yet) """
        
        if (not DC): command.SV *= self.SCTRL_num_liveAd_robot.value()
        msg, msgLen = UTIL.ROBO_tcpip.send(command)
        
        if (msg == True):
            
            mutex.lock()

            UTIL.ROBO_comm_queue.add    (command)
            UTIL.showOnTerminal         (f"SEND:    ID: {command.ID}  MT: {command.MT}  PT: {command.PT} \t|| COOR_1: {command.COOR_1}"\
                                         f"\n\t\t\t|| COOR_2: {command.COOR_2}"\
                                         f"\n\t\t\t|| SV:     {command.SV} \t|| SBT: {command.SBT}   SC: {command.SC}   Z: {command.Z}"\
                                         f"\n\t\t\t|| TOOL:   {command.TOOL}")
            UTIL.SC_curr_comm_id += 1
            if (DC): UTIL.SC_queue.increment()

            mutex.unlock()
                
            self.TCP_ROB_disp_writeBuffer.setText   (str(msg))
            self.TCP_ROB_disp_bytesWritten.setText  (str(msgLen))
            return msg

        elif (msg == ValueError):
            self.logEntry('CONN','TCPIP class "ROBO_tcpip" encountered ValueError in sendCommand, data length: ' + str(msgLen))
            self.TCP_ROB_disp_writeBuffer.setText   ('ValueError')
            self.TCP_ROB_disp_bytesWritten.setText  (str(msgLen))
        
        elif (msg == RuntimeError or msg == OSError):
            self.logEntry('CONN','TCPIP class "ROBO_tcpip" encountered RuntimeError/OSError in sendCommand..')
            self.TCP_ROB_disp_writeBuffer.setText   ('RuntimeError/OSError')
            self.TCP_ROB_disp_bytesWritten.setText  (str(msgLen))
        
        else:
            self.logEntry('CONN','TCPIP class "ROBO_tcpip" encountered ' + str(msg))
            self.TCP_ROB_disp_writeBuffer.setText   ('unspecified error')
            self.TCP_ROB_disp_bytesWritten.setText  (str(msgLen))
    
        return msg






    def setZero(self,axis):
        """ overwrite DC_curr_zero, uses deepcopy to avoid mutual large mutual exclusion blocks """

        newZero = copy.deepcopy(UTIL.DC_curr_zero)
        currPos = copy.deepcopy(UTIL.STT_pos)

        # 7 is a placeholder for Q, which can not be set by hand
        if 1 in axis:   newZero.X     = currPos.X
        if 2 in axis:   newZero.Y     = currPos.Y
        if 3 in axis:   newZero.Z     = currPos.Z
        if 4 in axis:   newZero.X_ori = currPos.X_ori
        if 5 in axis:   newZero.Y_ori = currPos.Y_ori
        if 6 in axis:   newZero.Z_ori = currPos.Z_ori
        if 8 in axis:   newZero.EXT   = currPos.EXT
        
        mutex.lock()
        UTIL.DC_curr_zero = newZero
        mutex.unlock()

        self.logEntry('DCom',f"current zero position updated: ({UTIL.DC_curr_zero})")






    

    #####################################################################################################
    #                                           CLOSE UI                                                #
    #####################################################################################################

    def closeEvent(self, event):
        """ exit all threads and connections clean(ish) """

        self.logEntry('GNRL','closeEvent signal.')
        self.logEntry('GNRL','end threading, delete Threads...')
        
        if(UTIL.ROBO_tcpip.connected):
            self.logEntry('CONN','closing TCP connections...')
            self.robotStopCommand()

            self.roboCommThread.quit()
            UTIL.ROBO_tcpip.close()
            self.roboCommThread.wait()

            self.pumpCommThread.quit()
            self.pumpCommThread.wait()

        self.roboCommThread.deleteLater()

        self.logEntry('GNRL','exiting GUI.')
        event.accept()








####################################################   MAIN  ####################################################

# mutual exclusion object, used to manage global data exchange
mutex = QMutex()




# only do the following if run as main program
if __name__ == '__main__':

    from libs.PRINT_win_dialogs import strdDialog
    import libs.PRINT_data_utilities as UTIL

    # import PyQT UIs (converted from .ui to .py)
    from ui.UI_mainframe_v5 import Ui_MainWindow



    logpath = UTIL.createLogfile()

    # overwrite ROBO_tcpip for testing, delete later
    UTIL.ROBO_tcpip.IP = 'localhost'
    UTIL.ROBO_tcpip.PORT = 10001
    UTIL.ROBO_tcpip.C_TOUT = 30.0
    UTIL.ROBO_tcpip.RW_TOUT = 1
    UTIL.ROBO_tcpip.R_BL = 36
    UTIL.ROBO_tcpip.W_BL = 159

    # start the UI and assign to app
    app = 0                             # leave that here so app doesnt include the remnant of a previous QApplication instance
    win = 0
    app = QApplication(sys.argv)
    win = Mainframe(lpath=logpath)
    win.show()

    # start application (uses sys for CMD)
    app.exec()
    # sys.exit(app.exec())