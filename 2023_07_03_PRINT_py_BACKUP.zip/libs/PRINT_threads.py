#   This work is licensed under Creativ Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
#   (https://creativecommons.org/licenses/by-sa/4.0/). Feel free to use, modify or distribute this code as  
#   far as you like, so long as you make anything based on it publicly avialable under the same license.


####################################################   IMPORTS  ####################################################

from PyQt5.QtCore import QObject,QTimer,QMutex,pyqtSignal
from . import PRINT_data_utilities as UTIL


# import interface for Toshiba frequency modulator by M-TEC
from mtec.mtec_mod import MtecMod








####################################################   WORKER   ####################################################

class PumpCommWorker(QObject):
    """ manages data updates and keepalive commands to pump """

    dataReceived    = pyqtSignal()
    dataSend        = pyqtSignal(int,str,int)
    logError        = pyqtSignal(str,str)

    mtecInterface   = MtecMod('01')



    def run(self):
        """ start timer with standard operation on timeout,
            connect to pump via M-Tec Interface """

        self.loopTimer = QTimer()
        self.loopTimer.setInterval(250)
        self.loopTimer.timeout.connect(self.loop)

        if ('COM' in UTIL.PUMP1_tcpip.PORT):
            self.loopTimer.start()
            self.mtecInterface.serial_port = UTIL.PUMP1_tcpip.PORT
            self.mtecInterface.connect()

        else:
            self.logError('CONN','no COM-port given, TCP/IP not supported, could not connect')



    def stop(self):
        """ stop timer """
        
        self.loopTimer.stop()
        self.mtecInterface.stop()
        self.loopTimer.deleteLater()



    def loop(self):
        """ not a real loop but you know what I mean,
            standard operations"""

        # use modified mtec setter (changed to function), recognizes value change by itself, returns ans and command str
        newSpeed = UTIL.PUMP1_speed
        res = self.mtecInterface.setSpeed(newSpeed)
        if (res is not None): 
            command,ans = res[0],res[1]
            self.dataSend.emit(newSpeed,command,ans)

        # keepAlive
        self.mtecInterface.keepAlive()

        # get data 
        freq    = self.mtecInterface.frequency
        volt    = self.mtecInterface.voltage
        amps    = self.mtecInterface.current
        torq    = self.mtecInterface.torque
        print(f"frq: {freq}, vol: {volt}, amps: {amps}, trq: {torq}")
        self.dataReceived.emit()

        





class RoboCommWorker(QObject):
    """ a worker object that check every 50 ms if the Robot queue has empty slots (according to ROBO_comm_forerun),
        emits signal to send data if so, beforehand
        checks the TCPIP connection every 50 ms and writes the result to global vars """


    queueEmtpy      = pyqtSignal()
    sendElem        = pyqtSignal(UTIL.QEntry)
    dataUpdated     = pyqtSignal(str, UTIL.Coor, float, int)
    logError        = pyqtSignal(str,str)



    def run(self):
        """ start timer, receive and send on timeout """

        self.checkTimer = QTimer()
        self.checkTimer.setInterval      (50)
        self.checkTimer.timeout.connect  (self.receive)
        self.checkTimer.timeout.connect  (self.send)
        self.checkTimer.start()



    def stop(self):
        """ stop timer """

        self.checkTimer.stop()
        self.checkTimer.deleteLater()    



    def receive(self):
        """ receive 36-byte data block, write to STT vars """

        ans,rawData,state = UTIL.ROBO_tcpip.receive()
        print(f"RECEIVED:    {ans}")

        if (state == True):
            pos             = UTIL.Coor( ans.X
                                        ,ans.Y
                                        ,ans.Z
                                        ,ans.X_ORI
                                        ,ans.Y_ORI
                                        ,ans.Z_ORI
                                        ,0
                                        ,ans.EXT)
            toolSpeed       = ans.TOOL_SPEED
            robo_comm_id    = ans.ID

            mutex.lock()
            UTIL.showOnTerminal(f"RECV:    ID {robo_comm_id},   {pos}   ToolSpeed: {toolSpeed}")
            try:
                while (UTIL.ROBO_comm_queue[0].ID < robo_comm_id):  UTIL.ROBO_comm_queue.popFirstItem()
            except AttributeError: pass
            mutex.unlock()

            self.dataUpdated.emit( str(rawData)
                                  ,pos
                                  ,toolSpeed
                                  ,robo_comm_id)
            
        else:
            mutex.lock()
            UTIL.showOnTerminal(f"RECV: error ({ans}) from TCPIP class ROBO_tcpip, data: {rawData}")
            mutex.unlock()

            self.logError.emit('CONN', f"error ({ans}) from TCPIP class ROBO_tcpip, data: {rawData}")
        
    
    
    def send(self):
        """  signal mainframe to send queue element if qProcessing and robot queue has space """

        if(UTIL.SC_qProcessing):
            if( len(UTIL.SC_queue) == 0 ):  self.queueEmtpy.emit()

            elif( (UTIL.STT_robo_comm_id + UTIL.ROBO_comm_fr) 
                > UTIL.SC_queue[0].ID ):
                
                mutex.lock()

                elem = UTIL.SC_queue.popFirstItem()
                if (elem == IndexError):    self.queueEmtpy.emit()
                else:                       self.sendElem.emit(elem)
                
                mutex.unlock()






####################################################   MAIN  ####################################################

mutex = QMutex()